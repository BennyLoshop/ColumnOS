// =================== 自动刷新 apps 列表 ===================

async function autoRefreshAppList(interval = 2000) {
    while (true) {
        const start = Date.now();
        try {
            const list = await getAppList();  // 获取最新应用列表
            await setAppList(list);                 // 更新全局 apps
        } catch (e) {
            console.error("刷新应用列表失败:", e);
        }
        const elapsed = Date.now() - start;
        // 等待 interval - 已耗时间，确保至少间隔 interval 毫秒
        await new Promise(resolve => setTimeout(resolve, Math.max(0, interval - elapsed)));
    }
}

(function () {
    const fakeJsToJava = {
        checkUrls: function (urls) {
            console.log("Fake JsToJava.checkUrls:", urls);
            return "[]";
        }
    };

    function override() {
        try {
            Object.defineProperty(window, 'JsToJava', {
                value: fakeJsToJava,
                writable: true,        // 仍允许你自己的 setInterval 覆盖
                configurable: true,    // 允许再次重写
                enumerable: false
            });
        } catch (e) { }
    }

    // 首次覆盖
    override();

    // 每 100ms 再覆盖一次
    setInterval(override, 100);
})();

autoRefreshAppList(100);//1

// 初始化自己的历史记录 state// 初始化自己的历史记录 state
history.pushState(null, '', location.href);

// 拦截浏览器返回按钮和安卓返回键
function blockBackButton(win) {
    if (!win) return;

    // 拦截浏览器返回
    win.addEventListener('popstate', (e) => {
        e.preventDefault();
        history.pushState(null, '', location.href);
    });

}

// 定时任务：0.1s 拦截自己和所有 iframe（排除 #columnos-iframe）
setInterval(() => {
    // 自己
    blockBackButton(window);
}, 100);
